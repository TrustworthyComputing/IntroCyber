#pip install pycryptodome
#pip install Pillow
#pip install urllib3
from Crypto import Random
from Crypto.Cipher import AES
from PIL import Image
from urllib import request

# Generate key for AES-128
key = Random.get_random_bytes(16)


img = Image.open("new_hen.png", "r")
ptxt = img.tobytes()


# ECB 

# declare AES object with ECB mode
cipher = AES.new(key, AES.MODE_ECB)
# encrypt ptxt
ctxt = cipher.encrypt(ptxt)
# save image
ecb_img = Image.frombytes(img.mode, img.size, ctxt)
ecb_img.save('ecb.png')


# CBC
# make IV using Crypto.Random
iv1 = Random.get_random_bytes(16)
# declare AES object with CBC mode 
cipher = AES.new(key, AES.MODE_CBC, iv=iv1)
# encrypt ptxt
ctxt = cipher.encrypt(ptxt)
# save image
cbc_img = Image.frombytes(img.mode, img.size, ctxt)
cbc_img.save('cbc.png')
