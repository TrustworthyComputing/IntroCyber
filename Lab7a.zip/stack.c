#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char secret[10] = "fl0weDOv3r" ;

void shell()
{   //never called
    printf("\n==Attack==\n");
    printf("%s\n", secret) ;
    exit(0) ;
}

void vuln(char * s, int count){
    char buff[16];
    printf("vuln() has received %d bytes\n", count);
    memcpy(buff, s, count); //no bounds check
}

void exploit(){
    FILE * f;
    char overflow[64];
    memset(&overflow, 0x41, 64); //fill with character 'A'
    
    //TODO: Fill in values for this code
    unsigned int offset = ??; //offset of return address in vuln()
    unsigned long redirect = (unsigned long) ?? ; //set shell() as a redirection target
    overflow[offset + ?] =  (redirect >> 56) & 0xff;
    overflow[offset + ?] =  (redirect >> 48) & 0xff;
    overflow[offset + ?] =  (redirect >>  40) & 0xff;
    overflow[offset + ?] =  (redirect >>  32) & 0xff;
    overflow[offset + ?] =  (redirect >>  24) & 0xff;
    overflow[offset + ?] =  (redirect >>  16) & 0xff;
    overflow[offset + ?] =  (redirect >>  8) & 0xff;
    overflow[offset + ?] =   redirect        & 0xff;
    
    f = fopen("overflow.txt", "w");
    fwrite(overflow, 64, 1, f);
    fclose(f);
}

int main(int argc, char **argv){
    printf("Main Addr: %lx\n", (unsigned long) main);
    char count;
    FILE * f;
    char overflow[64];
    char command[20];


    if (argc < 2) {
        printf("Missing first argument (integer). \nPlease run with input integer argument\n\"./stack <int>\"\nExiting...\n");
        return 0;
    }

    count = (char) atoi(argv[1]);

    if (!(count > 0)) {
        printf("Incorrect first argument (%d). Exiting...\n", count);
        return 0;
    }
    
    exploit(); //helper function to prepare a malicious input file

    printf("Reading %d bytes from file\n", count);

    f = fopen("overflow.txt", "r");
    if (f != NULL) {
        fread(overflow, sizeof(char), count, f);
        fclose(f);
        vuln(overflow, count);
    }
    else {
        printf("Input file does not exist. Exiting...\n");
        return 0;
    }

  printf("Control has returned to main()\nNormal operation.\n");
  return 1;
}
