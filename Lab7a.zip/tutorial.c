#include<stdlib.h>
#include<stdio.h>
#include<string.h>


char* get_input(int arg_size, char* arg_buff, int b)
{
        int notsecret = 0xffffff00;
        int secret = 0xc4e60456;
        char padding[16];
        char buff[32];
        memset(buff, 0, sizeof(buff)); // Zero-out the buffer.
        memset(padding, 0xa5, sizeof(padding)); // Zero-out the padding.


        printf("Padding: %lx\n", (unsigned long)  padding) ;
        printf("Buff: %lx\n", (unsigned long) buff) ;
        printf("Not Secret: %lx\n", (unsigned long) &notsecret) ;
        printf("Secret: %lx\n", (unsigned long) &secret) ;
        printf("Arg Buff1: %lx\n", (unsigned long) arg_buff) ;
        printf("Arg Buff2: %lx\n", (unsigned long) &arg_buff) ;
        printf("A: %lx B: %lx\n", (unsigned long) &arg_size, (unsigned long) &b) ;  
        printf("Input some text: ");

        gets(buff); 
        strncpy((char*) arg_buff, buff, arg_size) ;

        //Case 1
        if (secret == 0x61626364) {
                puts("You did it! Congratuations!");
        
                //Case 2
        } else if (notsecret != 0xffffff00) {
                puts("Uhmm... maybe you overflowed too much. Try deleting a few characters.");

        //Case 3
        } else if (secret != 0xc4e60456) {
                puts("Wow you overflowed the secret value! Now try controlling the value of it!");
                printf("S:%x\n", secret) ;
        }

        //Case 4
        else {
                puts("Maybe you haven't overflowed enough characters? Try again?");
        }
}

int main()
{
        int data_len = 256 ;
        char* data = malloc(data_len) ;
        get_input(data_len, data, 0) ;
        data[255] = '\0' ;
        printf("%s\n", data) ;
        free(data) ;
        exit(0) ;
}
