#include <stdio.h>
#include <unistd.h>
#include <string.h>


int main(int argc, char* argv[])
{

    long int secret_num = 0xde1abea7c1a5f1ed;
    char hello[7] = "Hello \0";

    printf(hello);
    printf(argv[1]) ;
    printf("! You'll never get my secret!\n");
    return 0;
}
