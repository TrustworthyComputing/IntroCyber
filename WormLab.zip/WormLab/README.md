# Lab setup for the Morris Worm Lab

- `worm/`: contains the provided skeleton worm code. 
- `internet-nano/`: contains the nano Internet emulation files. 
- `emulator-code/`: contains the Python code to generate the emulation files. 
- `shellcode/`: contains the source code of the Shellcode.
