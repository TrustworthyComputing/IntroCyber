from flask import Flask, request, render_template
import os

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        id = request.form.get('id')
        query = 'sudo mysql -u root -e "SELECT * FROM students.cohort WHERE id=' + id + ';"'
        data = os.popen(query).read()
        return render_template('index.html', data=data)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
