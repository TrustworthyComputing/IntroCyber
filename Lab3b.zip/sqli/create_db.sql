-- Create the "students" database (if it doesn't already exist)
CREATE DATABASE IF NOT EXISTS students;

-- Use the "students" database
USE students;

-- Create the "cohort" table
CREATE TABLE IF NOT EXISTS cohort (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    course VARCHAR(255) NOT NULL
);

-- Insert the specified entries
INSERT INTO cohort (name, course) VALUES
    ('alice', '465'),
    ('nick', '472'),
    ('bob', '202');
