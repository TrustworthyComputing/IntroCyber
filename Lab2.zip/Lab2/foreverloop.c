#include <unistd.h>
#include<stdint.h>
#include<stdio.h>

int main()
{
  uint64_t cnt = 0;
  uint64_t power = 1;

  while(1)
  {
    if(cnt == power)
    { 
      printf("%ld\n", cnt) ;
      power = power * 10 ;
    }
    cnt++ ;
  }
}

